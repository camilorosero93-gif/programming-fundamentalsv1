# Algoritmos Básicos en PSeInt

Colección de algoritmos básicos desarrollados en PSeInt para resolver problemas cotidianos y matemáticos sencillos.

## Lista de Programas

1. **Calculadora de Descuento** (`1_calcular_descuento.psc`)
2. **Velocidad Promedio** (`2_calcular_velocidad_promedio.psc`)
3. **Conversor de Kilómetros a Metros** (`3_convertir_kilometros_a_metros.psc`)
4. **Área de un Círculo** (`4_calcular_area_circulo.psc`)
5. **Consumo de Combustible** (`5_calcular_consumo_combustible.psc`)
6. **Total de Compra** (`6_calcular_total_compra.psc`)
7. **Promedio de Cinco Números** (`7_calcular_promedio.psc`)
8. **Total de Servicios Públicos** (`8_calcular_total_servicios.psc`)
9. **Conversor de Horas a Minutos y Segundos** (`9_convertir_horas.psc`)

## ¿Cómo usar?
Puedes abrir cualquiera de estos archivos `.psc` directamente en el software **PSeInt** para ejecutarlos y probarlos.
