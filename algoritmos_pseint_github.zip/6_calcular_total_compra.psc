Algoritmo calcular_total_compra
    Definir precio_unitario, valor_total Como Real
    Definir cantidad Como Entero
    Definir nombre_producto Como Caracter
    
    precio_unitario <- 0
    cantidad <- 0
    valor_total <- 0
    nombre_producto <- ""
    
    Escribir "Ingrese el nombre del producto:"
    Leer nombre_producto
    
    Escribir "Ingrese el precio unitario del producto:"
    Leer precio_unitario
    
    Escribir "Ingrese la cantidad comprada:"
    Leer cantidad
    
    valor_total <- precio_unitario * cantidad
    
    Escribir "El valor total de la compra para ", nombre_producto, " es: ", valor_total
FinAlgoritmo