Algoritmo calcular_total_servicios
    Definir energia, agua, gas, internet, total Como Real
    energia <- 0
    agua <- 0
    gas <- 0
    internet <- 0
    total <- 0
    
    Escribir "Ingrese el valor del servicio de energía:"
    Leer energia
    
    Escribir "Ingrese el valor del servicio de agua:"
    Leer agua
    
    Escribir "Ingrese el valor del servicio de gas:"
    Leer gas
    
    Escribir "Ingrese el valor del servicio de internet:"
    Leer internet
    
    total <- energia + agua + gas + internet
    
    Escribir "El valor total que debe pagar el usuario por todos los servicios es: ", total
FinAlgoritmo