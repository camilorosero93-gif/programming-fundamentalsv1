Algoritmo calcular_area_circulo
    Definir radio, area, PI Como Real
    radio <- 0
    area <- 0
    PI <- 3.1416
    
    Escribir "Ingrese el radio del círculo:"
    Leer radio
    
    area <- PI * (radio * radio)
    
    Escribir "El área del círculo es: ", area
FinAlgoritmo