Algoritmo calcular_descuento
    Definir precio_original, porcentaje_descuento, valor_descuento, precio_final Como Real
    precio_original <- 0
    porcentaje_descuento <- 0
    valor_descuento <- 0
    precio_final <- 0
    
    Escribir "Ingrese el precio original del producto:"
    Leer precio_original
    
    Escribir "Ingrese el porcentaje de descuento:"
    Leer porcentaje_descuento
    
    valor_descuento <- precio_original * (porcentaje_descuento / 100)
    precio_final <- precio_original - valor_descuento
    
    Escribir "El valor del descuento es: ", valor_descuento
    Escribir "El precio final que debe pagar el cliente es: ", precio_final
FinAlgoritmo