Algoritmo calcular_velocidad_promedio
    Definir distancia, tiempo, velocidad Como Real
    distancia <- 0
    tiempo <- 0
    velocidad <- 0
    
    Escribir "Ingrese la distancia recorrida:"
    Leer distancia
    
    Escribir "Ingrese el tiempo empleado:"
    Leer tiempo
    
    velocidad <- distancia / tiempo
    
    Escribir "La velocidad promedio del vehículo es: ", velocidad
FinAlgoritmo