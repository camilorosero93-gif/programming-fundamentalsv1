Algoritmo convertir_horas
    Definir horas, minutos, segundos Como Real
    horas <- 0
    minutos <- 0
    segundos <- 0
    
    Escribir "Ingrese la cantidad de horas:"
    Leer horas
    
    minutos <- horas * 60
    segundos <- horas * 3600
    
    Escribir "La cantidad en minutos es: ", minutos
    Escribir "La cantidad en segundos es: ", segundos
FinAlgoritmo