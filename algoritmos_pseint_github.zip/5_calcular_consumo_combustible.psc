Algoritmo calcular_consumo_combustible
    Definir kilometros, litros, consumo_promedio Como Real
    kilometros <- 0
    litros <- 0
    consumo_promedio <- 0
    
    Escribir "Ingrese la cantidad de kilómetros recorridos:"
    Leer kilometros
    
    Escribir "Ingrese la cantidad de combustible consumido en litros:"
    Leer litros
    
    consumo_promedio <- kilometros / litros
    
    Escribir "El consumo promedio de combustible es: ", consumo_promedio, " km/l"
FinAlgoritmo