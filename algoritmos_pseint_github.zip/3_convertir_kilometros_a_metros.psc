Algoritmo convertir_kilometros_a_metros
    Definir kilometros, metros Como Real
    kilometros <- 0
    metros <- 0
    
    Escribir "Ingrese la distancia en kilómetros:"
    Leer kilometros
    
    metros <- kilometros * 1000
    
    Escribir "La distancia en metros es: ", metros
FinAlgoritmo